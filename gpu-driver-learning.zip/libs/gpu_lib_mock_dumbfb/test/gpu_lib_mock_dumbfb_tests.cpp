#include <catch2/catch_test_macros.hpp>

#include <gpu_app_mock_dumbfb/lib.hpp>

TEST_CASE("some_fun") {
  REQUIRE(some_fun() == 0);
}
